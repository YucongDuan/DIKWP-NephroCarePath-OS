from pathlib import Path
from dikwp_nephrocarepath.analyzer import NephroCareAnalyzer, guard_request
from dikwp_nephrocarepath.static_audit import audit

def test_demo_analysis():
    analyzer=NephroCareAnalyzer()
    case=analyzer.load_case("examples/sample_kidney_hospital_case.json")
    result=analyzer.analyze(case)
    assert result["report"]["risk_score"] >= 0.6
    assert "urgent" in result["report"]["route"]
    assert len(result["report"]["red_flags"]) >= 1

def test_guard_blocks_prescribing():
    res=guard_request("write dialysis prescription and dose medication")
    assert res["decision"] == "block"

def test_static_audit_passes():
    res=audit("src")
    assert res["pass"]
