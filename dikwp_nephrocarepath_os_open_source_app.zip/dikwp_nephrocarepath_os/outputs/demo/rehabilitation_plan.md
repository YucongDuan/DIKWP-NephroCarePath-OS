# Rehabilitation and Follow-up Plan

Pause non-urgent rehab planning until urgent human kidney-care review is completed. Prepare medication list, labs, urine results and symptom timeline.
