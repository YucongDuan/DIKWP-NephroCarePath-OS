# Recommendations

## Overall route

urgent_nephrology_or_emergency_review

## Minimum actions

- Verify patient identity and data source.
- Review red flags before routine education.
- Complete missing evidence queue.
- Route Action Tickets to licensed nephrology team.
- Use outputs only as review packets, not clinical orders.

## Integration ideas

- Nephrology clinic pre-visit preparation.
- Dialysis education class preparation.
- CKD follow-up calendar support.
- Transplant education checklist support.
- AKI/AKD post-discharge follow-up preparation.
