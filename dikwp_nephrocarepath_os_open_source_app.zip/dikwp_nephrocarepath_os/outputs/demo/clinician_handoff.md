# Clinician Handoff Draft

## Case

nephrocare-demo-001 / kidney hospital nephrology intake and care-preparation demo

## Themes

- nephrotoxin stewardship: urgent_nephrology_or_emergency_review
- rehabilitation and follow-up support: urgent_nephrology_or_emergency_review
- kidney replacement therapy preparation: urgent_nephrology_or_emergency_review
- glomerular disease review: urgent_nephrology_or_emergency_review
- CKD risk and progression planning: urgent_nephrology_or_emergency_review

## Red flags

- shortness of breath: possible volume overload or cardiopulmonary emergency
- egfr 12: kidney failure range marker

## Evidence gaps



## Boundary

This handoff is a preparation draft and requires clinician review. It does not make diagnosis, prescribe treatment, select dialysis modality or determine transplant eligibility.
