# Patient Education Draft: Kidney Care Preparation

This draft is for clinician review before patient use.

## Current route

urgent_nephrology_or_emergency_review

## What to bring to kidney clinic

- Recent serum creatinine / eGFR results.
- Urine albumin-creatinine ratio or urinalysis.
- Blood pressure log if available.
- Medication, supplement, herbal product and contrast exposure list.
- Diabetes, hypertension and cardiovascular history.
- Imaging reports, especially renal ultrasound if available.

## Red flag reminders

- shortness of breath: possible volume overload or cardiopulmonary emergency
- egfr 12: kidney failure range marker

## Important boundary

This draft does not diagnose kidney disease, prescribe medication, select dialysis modality, or decide transplant eligibility.
