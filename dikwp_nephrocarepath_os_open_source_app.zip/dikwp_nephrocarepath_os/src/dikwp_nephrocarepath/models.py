from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class KidneyCase:
    case_id: str
    setting: str
    demographics: Dict[str, Any]
    symptoms: List[str]
    history: List[str]
    labs: Dict[str, Any]
    urine: Dict[str, Any]
    imaging: Dict[str, Any]
    medications: List[str]
    exposures: List[str]
    patient_goals: List[str]
    social_barriers: List[str]
    ai_inputs: List[Dict[str, Any]] = field(default_factory=list)

@dataclass
class DecisionCard:
    case_id: str
    theme: str
    risk_score: float
    route: str
    semantic_stability: str
    red_flags: List[str]
    evidence_gaps: List[str]
    residuals: List[str]
    reviewer: str

@dataclass
class ActionTicket:
    ticket_id: str
    owner: str
    priority: str
    action: str
    evidence_refs: List[str]
    rollback_plan: str
    kill_conditions: List[str]

@dataclass
class NephroReport:
    system: str
    version: str
    case_id: str
    setting: str
    route: str
    risk_score: float
    red_flags: List[str]
    decision_cards: List[Dict[str, Any]]
    action_tickets: List[Dict[str, Any]]
    safety_boundary: str
