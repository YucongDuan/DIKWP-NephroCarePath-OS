import json, math
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Any, List
from .models import KidneyCase, DecisionCard, ActionTicket, NephroReport

RED_FLAG_TERMS = {
    "confusion": "possible uremic encephalopathy or severe systemic illness",
    "seizure": "neurologic emergency",
    "shortness of breath": "possible volume overload or cardiopulmonary emergency",
    "chest pain": "possible cardiovascular emergency",
    "severe weakness": "possible severe metabolic abnormality",
    "no urine": "possible obstruction or severe AKI",
    "anuria": "possible obstruction or severe AKI",
    "blood in urine with clots": "possible urinary obstruction/bleeding risk",
    "fever with transplant": "possible transplant infection/rejection context",
    "severe flank pain": "possible stone/obstruction/infection emergency",
    "pregnancy with kidney disease": "high-risk pregnancy kidney review",
}

DANGER_LABS = {
    "potassium": (6.0, "hyperkalemia risk"),
    "bicarbonate": (16, "metabolic acidosis risk", "low"),
    "creatinine": (5.0, "advanced kidney dysfunction marker"),
    "egfr": (15, "kidney failure range marker", "low"),
    "hemoglobin": (8.0, "severe anemia context", "low"),
}

REQUIRED_FIELDS = ["creatinine", "egfr", "potassium", "bicarbonate", "hemoglobin"]
REQUIRED_URINE = ["uacr", "urinalysis"]
REQUIRED_IMAGING = ["renal_ultrasound"]

class NephroCareAnalyzer:
    def __init__(self, policy: Dict[str, Any] = None):
        self.policy = policy or {}

    def load_case(self, path: str) -> KidneyCase:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return KidneyCase(**data)

    def detect_red_flags(self, case: KidneyCase) -> List[str]:
        text = " ".join(case.symptoms + case.history + case.exposures).lower()
        flags = []
        for term, desc in RED_FLAG_TERMS.items():
            if term in text:
                flags.append(f"{term}: {desc}")
        labs = case.labs or {}
        for lab, config in DANGER_LABS.items():
            if lab in labs and labs[lab] is not None:
                value = labs[lab]
                if isinstance(config, tuple) and len(config) == 3 and config[2] == "low":
                    if value <= config[0]: flags.append(f"{lab} {value}: {config[1]}")
                else:
                    if value >= config[0]: flags.append(f"{lab} {value}: {config[1]}")
        return flags

    def evidence_gaps(self, case: KidneyCase) -> List[str]:
        gaps = []
        for f in REQUIRED_FIELDS:
            if f not in case.labs or case.labs.get(f) in [None, ""]:
                gaps.append(f"missing lab: {f}")
        for f in REQUIRED_URINE:
            if f not in case.urine or case.urine.get(f) in [None, ""]:
                gaps.append(f"missing urine evidence: {f}")
        for f in REQUIRED_IMAGING:
            if f not in case.imaging or case.imaging.get(f) in [None, ""]:
                gaps.append(f"missing imaging evidence: {f}")
        if not case.medications:
            gaps.append("missing medication list")
        if not case.patient_goals:
            gaps.append("missing patient goals")
        return gaps

    def score_risk(self, case: KidneyCase, red_flags: List[str], gaps: List[str]) -> float:
        score = 0.0
        score += min(0.55, len(red_flags) * 0.18)
        score += min(0.2, len(gaps) * 0.025)
        egfr = case.labs.get("egfr")
        if isinstance(egfr, (int, float)):
            if egfr < 15: score += 0.25
            elif egfr < 30: score += 0.18
            elif egfr < 45: score += 0.1
        uacr = case.urine.get("uacr")
        if isinstance(uacr, (int, float)):
            if uacr >= 300: score += 0.12
            elif uacr >= 30: score += 0.06
        if any("transplant" in h.lower() for h in case.history): score += 0.15
        if any("dialysis" in h.lower() for h in case.history): score += 0.12
        if any("nsaid" in e.lower() or "herbal" in e.lower() or "contrast" in e.lower() for e in case.exposures): score += 0.08
        return round(min(1.0, score), 3)

    def route(self, case: KidneyCase, risk: float, red_flags: List[str]) -> str:
        if red_flags and risk >= 0.55:
            return "urgent_nephrology_or_emergency_review"
        if risk >= 0.65:
            return "urgent_nephrology_or_emergency_review"
        if risk >= 0.45:
            return "specialist_nephrologist_review_required"
        if risk >= 0.25:
            return "clinician_review_and_ckd_care_planning"
        return "education_and_followup_planning"

    def theme_signals(self, case: KidneyCase) -> List[str]:
        text = " ".join(case.symptoms + case.history + case.exposures + case.patient_goals).lower()
        labs = case.labs
        signals = set()
        if "diabetes" in text or "hypertension" in text or "uacr" in case.urine: signals.add("CKD risk and progression planning")
        if "transplant" in text: signals.add("kidney transplant follow-up")
        if "dialysis" in text or (isinstance(labs.get("egfr"), (int, float)) and labs.get("egfr") < 20): signals.add("kidney replacement therapy preparation")
        if "stone" in text or "flank" in text or "obstruction" in text: signals.add("obstruction or stones review")
        if "lupus" in text or "glomerul" in text or case.urine.get("proteinuria") == "heavy": signals.add("glomerular disease review")
        if "pregnancy" in text: signals.add("pregnancy and kidney disease review")
        if "herbal" in text or "nsaid" in text or "contrast" in text: signals.add("nephrotoxin stewardship")
        signals.add("rehabilitation and follow-up support")
        return list(signals)

    def semantic_stability(self, risk: float, gaps: List[str]) -> str:
        if risk >= 0.65: return "S2 Provisional Closure"
        if len(gaps) >= 6: return "S2 Provisional Closure"
        if len(gaps) >= 3: return "S3 Supported Closure"
        return "S4 Stable Operational Closure"

    def build_decision_cards(self, case: KidneyCase, risk: float, red_flags: List[str], gaps: List[str]) -> List[DecisionCard]:
        cards=[]
        for theme in self.theme_signals(case):
            if "replacement" in theme or "transplant" in theme or "glomerular" in theme:
                reviewer="nephrologist / specialty team"
            elif "nephrotoxin" in theme:
                reviewer="clinician + pharmacist review"
            else:
                reviewer="kidney care team"
            residuals = ["requires clinician context", "AI output cannot decide diagnosis or treatment"] + gaps[:3]
            cards.append(DecisionCard(case.case_id, theme, risk, self.route(case, risk, red_flags), self.semantic_stability(risk, gaps), red_flags, gaps, residuals, reviewer))
        return cards

    def build_action_tickets(self, cards: List[DecisionCard]) -> List[ActionTicket]:
        tickets=[]
        for idx, c in enumerate(cards, start=1):
            priority = "urgent" if "urgent" in c.route else ("high" if c.risk_score >= .45 else "routine")
            action = f"Prepare {c.theme} review packet; verify missing evidence; route to {c.reviewer}."
            tickets.append(ActionTicket(
                ticket_id=f"N-{idx:03d}",
                owner=c.reviewer,
                priority=priority,
                action=action,
                evidence_refs=["D-labs", "D-urine", "D-history"],
                rollback_plan="Withdraw draft packet, restore clinician-only workflow, and mark AI output as advisory-only.",
                kill_conditions=["new red flag", "lab conflict", "patient identity mismatch", "clinician disagreement", "missing critical evidence"]
            ))
        return tickets

    def dikwp_ledger(self, case: KidneyCase, cards: List[DecisionCard]) -> Dict[str, Any]:
        return {
            "D": {"symptoms": case.symptoms, "history": case.history, "labs": case.labs, "urine": case.urine, "imaging": case.imaging, "medications": case.medications, "exposures": case.exposures},
            "I": {"setting": case.setting, "themes": [c.theme for c in cards], "red_flags": cards[0].red_flags if cards else []},
            "K": {"knowledge_scope": "kidney care triage preparation, CKD/AKI evidence organization, dialysis/transplant preparation, rehab support", "not_knowledge_scope": "not diagnosis or prescribing"},
            "W": {"wisdom_boundaries": ["patient safety", "clinician responsibility", "no autonomous treatment", "privacy", "equity and access"]},
            "P": {"purpose": "prepare safer kidney care review, treatment discussion, rehab/follow-up support without replacing clinicians", "feedback": "clinician correction updates local pathway"},
            "R": {"reliability": "advisory / review-only", "semantic_stability": cards[0].semantic_stability if cards else "S2", "residuals": cards[0].residuals if cards else []}
        }

    def ai_model_registry(self) -> List[Dict[str, Any]]:
        return [
            {"model_id":"ckd-progression-draft-agent", "intended_use":"risk discussion preparation", "max_control_level":"advisory", "prohibited_use":"diagnosis/prescribing/dialysis prescription"},
            {"model_id":"aki-red-flag-auditor", "intended_use":"urgent review packet preparation", "max_control_level":"review-only", "prohibited_use":"emergency triage automation"},
            {"model_id":"dialysis-education-draft-agent", "intended_use":"patient education draft", "max_control_level":"draft-only", "prohibited_use":"dialysis modality assignment"},
            {"model_id":"transplant-prep-checklist-agent", "intended_use":"checklist preparation", "max_control_level":"draft-only", "prohibited_use":"transplant eligibility decision"}
        ]

    def education_pack(self, case: KidneyCase, route: str, red_flags: List[str]) -> str:
        red = "\n".join(f"- {r}" for r in red_flags) if red_flags else "- No acute red flags detected in the provided summary; clinician review still required."
        return f"""# Patient Education Draft: Kidney Care Preparation

This draft is for clinician review before patient use.

## Current route

{route}

## What to bring to kidney clinic

- Recent serum creatinine / eGFR results.
- Urine albumin-creatinine ratio or urinalysis.
- Blood pressure log if available.
- Medication, supplement, herbal product and contrast exposure list.
- Diabetes, hypertension and cardiovascular history.
- Imaging reports, especially renal ultrasound if available.

## Red flag reminders

{red}

## Important boundary

This draft does not diagnose kidney disease, prescribe medication, select dialysis modality, or decide transplant eligibility.
"""

    def rehab_plan(self, case: KidneyCase, route: str, red_flags: List[str]) -> str:
        if red_flags:
            return "# Rehabilitation and Follow-up Plan\n\nPause non-urgent rehab planning until urgent human kidney-care review is completed. Prepare medication list, labs, urine results and symptom timeline.\n"
        return """# Kidney Rehabilitation and Follow-up Support Plan

## Core supports

- Track fatigue, appetite, sleep, swelling, breathlessness and functional capacity.
- Prepare dietitian referral questions for sodium, potassium, phosphate, protein and fluid goals.
- Build a medication review list, especially NSAIDs, supplements and nephrotoxin exposures.
- Create a follow-up calendar for labs, urine tests, imaging and nephrology visits.
- Identify financial, transport, work, family and health-literacy barriers.

## Patient-centered goals

The plan should be adapted by clinicians and allied health professionals. It is not a prescription or dialysis plan.
"""

    def treatment_prep_plan(self, case: KidneyCase, cards: List[DecisionCard]) -> Dict[str, Any]:
        gaps = cards[0].evidence_gaps if cards else []
        return {
            "purpose": "prepare clinician treatment discussion; not prescribe treatment",
            "missing_evidence_to_verify": gaps,
            "review_questions": [
                "Is kidney injury acute, chronic, or acute-on-chronic based on prior creatinine/eGFR trend?",
                "Is albuminuria/proteinuria quantified and persistent?",
                "Are hyperkalemia, acidosis, anemia, CKD-MBD, volume overload or uremic symptoms present?",
                "Are nephrotoxins, contrast exposures, herbal supplements or unsafe medications present?",
                "Is kidney replacement therapy education or access planning needed?",
                "Are transplant education or conservative kidney management discussions appropriate?"
            ],
            "blocked_actions": ["prescribing", "dialysis prescription", "transplant eligibility decision", "drug discontinuation advice", "emergency disposition decision"]
        }

    def analyze(self, case: KidneyCase, out_dir: str = None) -> Dict[str, Any]:
        red_flags = self.detect_red_flags(case)
        gaps = self.evidence_gaps(case)
        risk = self.score_risk(case, red_flags, gaps)
        route = self.route(case, risk, red_flags)
        cards = self.build_decision_cards(case, risk, red_flags, gaps)
        tickets = self.build_action_tickets(cards)
        ledger = self.dikwp_ledger(case, cards)
        report = NephroReport(
            system="DIKWP NephroCarePath OS", version="0.1.0", case_id=case.case_id, setting=case.setting,
            route=route, risk_score=risk, red_flags=red_flags,
            decision_cards=[asdict(c) for c in cards], action_tickets=[asdict(t) for t in tickets],
            safety_boundary="No diagnosis, treatment, prescribing, dialysis prescription, transplant eligibility decision, or device control; clinician review required."
        )
        outputs = {
            "nephrocare_report.json": asdict(report),
            "dikwp_kidney_ledger.json": ledger,
            "triage_queue.json": {"route": route, "risk_score": risk, "red_flags": red_flags, "evidence_gaps": gaps},
            "treatment_prep_plan.json": self.treatment_prep_plan(case, cards),
            "rehabilitation_plan.md": self.rehab_plan(case, route, red_flags),
            "patient_education_pack.md": self.education_pack(case, route, red_flags),
            "clinician_handoff.md": self.clinician_handoff(case, cards, tickets),
            "ai_model_registry.json": self.ai_model_registry(),
            "recommendations.md": self.recommendations(route, cards),
            "action_tickets.json": [asdict(t) for t in tickets],
            "decision_cards.json": [asdict(c) for c in cards]
        }
        if out_dir:
            p=Path(out_dir); p.mkdir(parents=True, exist_ok=True)
            for name, content in outputs.items():
                fp=p/name
                if name.endswith(".json"):
                    fp.write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")
                else:
                    fp.write_text(str(content), encoding="utf-8")
            # csv exports
            import csv
            with (p/"decision_cards.csv").open("w", newline="", encoding="utf-8") as f:
                w=csv.DictWriter(f, fieldnames=["case_id","theme","risk_score","route","semantic_stability","reviewer"])
                w.writeheader(); [w.writerow({k:getattr(c,k) for k in w.fieldnames}) for c in cards]
            with (p/"action_tickets.csv").open("w", newline="", encoding="utf-8") as f:
                w=csv.DictWriter(f, fieldnames=["ticket_id","owner","priority","action"])
                w.writeheader(); [w.writerow({k:getattr(t,k) for k in w.fieldnames}) for t in tickets]
        return {"report": asdict(report), "outputs": outputs}

    def clinician_handoff(self, case: KidneyCase, cards: List[DecisionCard], tickets: List[ActionTicket]) -> str:
        themes = "\n".join(f"- {c.theme}: {c.route}" for c in cards)
        gaps = "\n".join(f"- {g}" for g in (cards[0].evidence_gaps if cards else []))
        flags = "\n".join(f"- {f}" for f in (cards[0].red_flags if cards else [])) or "- None detected from provided summary."
        return f"""# Clinician Handoff Draft

## Case

{case.case_id} / {case.setting}

## Themes

{themes}

## Red flags

{flags}

## Evidence gaps

{gaps}

## Boundary

This handoff is a preparation draft and requires clinician review. It does not make diagnosis, prescribe treatment, select dialysis modality or determine transplant eligibility.
"""

    def recommendations(self, route: str, cards: List[DecisionCard]) -> str:
        return f"""# Recommendations

## Overall route

{route}

## Minimum actions

- Verify patient identity and data source.
- Review red flags before routine education.
- Complete missing evidence queue.
- Route Action Tickets to licensed nephrology team.
- Use outputs only as review packets, not clinical orders.

## Integration ideas

- Nephrology clinic pre-visit preparation.
- Dialysis education class preparation.
- CKD follow-up calendar support.
- Transplant education checklist support.
- AKI/AKD post-discharge follow-up preparation.
"""

def guard_request(text: str) -> Dict[str, Any]:
    low = text.lower()
    blocked = ["dose", "prescribe", "dialysis prescription", "transplant eligible", "stop medication", "start medication", "ignore potassium", "bypass clinician", "emergency disposition", "diagnose me"]
    review = ["dialysis", "transplant", "acute kidney injury", "hyperkalemia", "pregnancy", "glomerulonephritis", "biopsy"]
    if any(b in low for b in blocked):
        return {"decision": "block", "reason": "request asks for diagnosis/prescribing/dialysis/transplant/emergency decision or unsafe self-management", "safe_redirect": "prepare clinician questions, evidence checklist, or patient education draft"}
    if any(r in low for r in review):
        return {"decision": "clinician_or_instructor_review_required", "reason": "kidney care high-impact topic requires professional review", "safe_redirect": "create review checklist or education-only explanation"}
    return {"decision": "allow_education_or_prep", "reason": "conceptual or care-preparation request", "safe_redirect": "provide educational, non-prescriptive content"}
