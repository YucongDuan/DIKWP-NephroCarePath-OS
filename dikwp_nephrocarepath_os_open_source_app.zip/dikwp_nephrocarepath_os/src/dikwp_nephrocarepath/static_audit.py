from pathlib import Path
import json

FORBIDDEN = [
    "requests", "urllib", "httpx", "socket", "subprocess", "os.system", "eval(", "exec(",
    "selenium", "playwright", "pyautogui", "pynput", "credential", "password"
]

def audit(root: str):
    findings=[]
    for path in Path(root).rglob("*.py"):
        text=path.read_text(encoding="utf-8", errors="ignore").lower()
        for term in FORBIDDEN:
            if term.lower() in text:
                # allow in static policy file itself? flag all except this file.
                if path.name == "static_audit.py" and term in text:
                    continue
                findings.append({"file": str(path), "term": term})
    return {"pass": not findings, "finding_count": len(findings), "findings": findings, "policy": "No network imports, subprocess, dynamic execution, credential capture, clinical decision automation, dialysis prescription, transplant eligibility automation, or device actuation in offline core."}

def write_report(root: str, out: str):
    result=audit(root)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
