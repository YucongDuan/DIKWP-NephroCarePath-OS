import argparse, json
from pathlib import Path
from .analyzer import NephroCareAnalyzer, guard_request
from .static_audit import write_report

def main():
    parser=argparse.ArgumentParser(prog="nephrocare")
    sub=parser.add_subparsers(dest="cmd", required=True)
    p=sub.add_parser("analyze")
    p.add_argument("case")
    p.add_argument("--out", default="outputs/demo")
    g=sub.add_parser("guard")
    g.add_argument("text")
    s=sub.add_parser("static-audit")
    s.add_argument("root")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args=parser.parse_args()
    if args.cmd=="analyze":
        analyzer=NephroCareAnalyzer()
        case=analyzer.load_case(args.case)
        result=analyzer.analyze(case, args.out)
        print(json.dumps({"case_id": case.case_id, "route": result["report"]["route"], "risk_score": result["report"]["risk_score"], "red_flags": result["report"]["red_flags"]}, ensure_ascii=False, indent=2))
    elif args.cmd=="guard":
        print(json.dumps(guard_request(args.text), ensure_ascii=False, indent=2))
    elif args.cmd=="static-audit":
        print(json.dumps(write_report(args.root, args.out), ensure_ascii=False, indent=2))
if __name__ == "__main__": main()
