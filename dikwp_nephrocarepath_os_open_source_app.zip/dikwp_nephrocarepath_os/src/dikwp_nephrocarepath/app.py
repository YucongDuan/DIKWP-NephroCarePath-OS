# Optional Streamlit placeholder. Install with pip install -e .[app]
def main():
    try:
        import streamlit as st
    except Exception:
        print("Install streamlit to run the app.")
        return
    st.title("DIKWP NephroCarePath OS")
    st.write("Kidney hospital triage, treatment-preparation and rehabilitation governance prototype.")
if __name__ == "__main__": main()
