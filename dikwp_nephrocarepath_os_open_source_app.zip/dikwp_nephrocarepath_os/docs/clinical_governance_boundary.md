# Clinical Governance Boundary

This project is a clinical-preparation and education-governance prototype. It is not a medical device. It does not produce clinical orders. It requires licensed clinician review.
