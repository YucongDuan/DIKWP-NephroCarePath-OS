# AI Model Registry and Validation

Every kidney AI model should have an intended use, input data scope, local validation status, prohibited uses, maximum control level and monitoring plan. Advisory models cannot become prescribing or dialysis decision systems without regulatory, institutional and clinical validation.
