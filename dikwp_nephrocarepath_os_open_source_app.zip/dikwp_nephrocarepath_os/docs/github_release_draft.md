# Release Draft

DIKWP NephroCarePath OS v0.1.0 provides a kidney hospital triage-preparation, treatment-discussion, dialysis/transplant preparation and rehabilitation governance prototype.

Highlights:

- DIKWP kidney ledger
- red flag scanner
- evidence gap queue
- treatment-prep plan
- rehab and follow-up plan
- clinician handoff
- AI model registry
- standalone browser demo
- offline CLI
