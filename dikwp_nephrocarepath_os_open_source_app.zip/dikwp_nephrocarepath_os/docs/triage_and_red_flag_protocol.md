# Triage and Red-Flag Protocol

Red flags include confusion, seizures, shortness of breath, chest pain, anuria, severe weakness, transplant with fever, severe flank pain, severe hyperkalemia context and combinations suggesting urgent kidney-care review. The system does not diagnose the cause. It only prepares urgent human review packets.
