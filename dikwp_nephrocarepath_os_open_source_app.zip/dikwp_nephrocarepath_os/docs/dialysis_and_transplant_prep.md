# Dialysis and Transplant Preparation

The system may help prepare education checklists about dialysis modalities, access planning questions, transplant education needs, social barriers and caregiver support. It must not assign dialysis modality, prescribe dialysis dose, determine vascular access procedure, approve transplant eligibility or replace transplant committee review.
