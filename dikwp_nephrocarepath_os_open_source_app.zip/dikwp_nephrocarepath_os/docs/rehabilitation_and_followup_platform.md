# Rehabilitation and Follow-up Platform

Kidney rehabilitation includes fatigue management, dietary referral questions, anemia/mineral bone disorder evidence tracking, medication review, exercise tolerance, social support, transportation and follow-up calendars. It pauses non-urgent rehab planning when urgent red flags are present.
