# Treatment Preparation Boundary

Treatment preparation means collecting missing evidence and preparing clinician questions. It does not mean prescribing medications, stopping medications, setting dialysis modality, deciding transplant eligibility or determining emergency disposition.
