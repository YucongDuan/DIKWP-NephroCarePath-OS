# Kidney Hospital Workflow

1. Intake receives patient summary and available data.
2. Red flag scanner detects urgent patterns.
3. Evidence gap scanner checks kidney-relevant data.
4. DIKWP ledger separates Data, Information, Knowledge, Wisdom, Purpose, Reliability.
5. Decision Cards route themes to kidney care roles.
6. Action Tickets create review tasks.
7. Clinicians verify and decide.
8. Patient education and rehab drafts are used only after review.
