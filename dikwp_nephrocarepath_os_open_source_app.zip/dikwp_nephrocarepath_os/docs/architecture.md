# Architecture

DIKWP NephroCarePath OS contains four layers:

1. **Intake Layer**: kidney case JSON, labs, urine, imaging, medications, patient goals and social barriers.
2. **SemanticClosure Layer**: red flags, evidence gaps, risk score, themes and DIKWP ledger.
3. **Care Preparation Layer**: decision cards, action tickets, treatment-prep questions, rehab plan and clinician handoff.
4. **Governance Layer**: AI model registry, static audit, clinical boundary, patient education review.

The system is offline-first and review-only.
