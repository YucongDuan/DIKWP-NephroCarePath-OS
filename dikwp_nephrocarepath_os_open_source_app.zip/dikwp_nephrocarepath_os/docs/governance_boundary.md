# Governance Boundary

No autonomous diagnosis, treatment, prescribing, dialysis prescription, transplant eligibility decision, emergency disposition, medical-device actuation, credential capture, or hidden telemetry.
