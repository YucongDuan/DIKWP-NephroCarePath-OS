# Roadmap

- v0.2: CKD risk heat-map adapter.
- v0.3: dialysis education module.
- v0.4: transplant preparation and social barrier module.
- v0.5: local hospital AI model registry UI.
- v1.0: clinician-validated pilot in a kidney hospital sandbox.
